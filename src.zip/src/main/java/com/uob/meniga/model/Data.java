package com.uob.meniga.model;

public class Data {

	private String outputValue;
	
	private String hashSum;
	
	public String getHashSum() {
		return hashSum;
	}

	public void setHashSum(String hashSum) {
		this.hashSum = hashSum;
	}

	public String getOutputValue() {
		return outputValue;
	}
	
	public void setOutputValue(String outputValue) {
		this.outputValue = outputValue;
	}
	
}
